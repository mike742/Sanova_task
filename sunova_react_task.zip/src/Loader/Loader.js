import React from 'react';
import '../Loader/Loader.css';

export default () => <div className="lds-dual-ring" />